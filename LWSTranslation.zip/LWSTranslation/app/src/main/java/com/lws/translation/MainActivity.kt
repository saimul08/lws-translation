package com.lws.translation

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("lws", MODE_PRIVATE)
        setContent {
            MaterialTheme {
                var apiKey by remember { mutableStateOf(prefs.getString("api_key", "") ?: "") }
                var saved by remember { mutableStateOf(false) }

                Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(Modifier.height(24.dp))
                    Image(
                        painterResource(R.drawable.logo), "LWS logo",
                        Modifier.size(120.dp).clip(CircleShape)
                    )
                    Spacer(Modifier.height(12.dp))
                    Text("LWS Translation", style = MaterialTheme.typography.headlineMedium)
                    Text("বাংলা ↔ English শব্দের অর্থ ও ব্যাখ্যা", textAlign = TextAlign.Center)
                    Spacer(Modifier.height(24.dp))

                    Text(
                        "১. নিচের বাটনে ক্লিক করে Accessibility সেটিংসে যান।\n" +
                        "২. 'LWS Translation' বেছে চালু করুন।\n" +
                        "৩. স্ক্রিনের উপরে ভাসমান বাটন আসবে। ক্লিক করে শব্দ লিখে খুঁজুন।",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = {
                        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    }) { Text("Accessibility সেটিংস খুলুন") }

                    Spacer(Modifier.height(32.dp))
                    Text("AI ব্যাখ্যা (ঐচ্ছিক, ইন্টারনেট লাগবে)", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = apiKey, onValueChange = { apiKey = it; saved = false },
                        label = { Text("Claude API key") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = {
                        prefs.edit().putString("api_key", apiKey.trim()).apply(); saved = true
                    }) { Text(if (saved) "সেভ হয়েছে ✓" else "সেভ করুন") }
                }
            }
        }
    }
}
