package com.lws.translation

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*

class FloatingService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private var bubble: ImageView? = null
    private var panel: LinearLayout? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        bubble?.let { runCatching { wm.removeView(it) } }
        panel?.let { runCatching { wm.removeView(it) } }
        super.onDestroy()
    }

    // ---------- Floating button ----------
    private fun showBubble() {
        val size = dp(52)
        val iv = ImageView(this).apply {
            setImageResource(R.drawable.logo)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.BLACK) }
            clipToOutline = true
            elevation = dp(6).toFloat()
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(300) }

        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        iv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt(); val dy = (e.rawY - downY).toInt()
                    if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true
                    if (moved) { lp.x = startX + dx; lp.y = startY + dy; wm.updateViewLayout(iv, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) togglePanel()
            }
            true
        }
        wm.addView(iv, lp)
        bubble = iv
    }

    // ---------- Search panel ----------
    private fun togglePanel() {
        if (panel != null) closePanel() else openPanel()
    }

    private fun closePanel() {
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
    }

    private fun openPanel() {
        val root = object : LinearLayout(this) {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                if (event.keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
                    closePanel(); return true
                }
                return super.dispatchKeyEvent(event)
            }
        }.apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(16))
            background = GradientDrawable().apply { cornerRadius = dp(20).toFloat(); setColor(Color.WHITE) }
            elevation = dp(10).toFloat()
        }

        // header
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply {
            text = "LWS Translation"; textSize = 17f; setTextColor(Color.BLACK)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(TextView(this).apply {
            text = "✕"; textSize = 20f; setPadding(dp(12), dp(4), dp(4), dp(4)); setTextColor(Color.DKGRAY)
            setOnClickListener { closePanel() }
        })
        root.addView(header)

        // input row
        val input = EditText(this).apply {
            hint = "শব্দ লিখুন (বাংলা / English)"
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setSingleLine(true)
            setTextColor(Color.BLACK); setHintTextColor(Color.GRAY)
        }
        val btn = Button(this).apply { text = "খুঁজুন" }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(btn)
        root.addView(row)

        // results
        fun label(t: String) = TextView(this).apply {
            text = t; textSize = 13f; setTextColor(Color.parseColor("#666666"))
            setPadding(0, dp(12), 0, dp(2))
        }
        fun body() = TextView(this).apply {
            textSize = 16f; setTextColor(Color.BLACK); setTextIsSelectable(true)
        }
        val status = TextView(this).apply { textSize = 12f; setTextColor(Color.GRAY) }
        val orthoTv = body()
        val bekkhaTv = body()
        val results = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(status)
            addView(label("অর্থ")); addView(orthoTv)
            addView(label("ব্যাখ্যা")); addView(bekkhaTv)
        }
        val maxH = (resources.displayMetrics.heightPixels * 0.45).toInt()
        root.addView(ScrollView(this).apply { addView(results) },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, maxH))

        // search logic
        fun search() {
            val word = input.text.toString().trim()
            if (word.isEmpty()) return
            orthoTv.text = ""; bekkhaTv.text = ""; status.text = "খুঁজছি…"
            val tag = System.nanoTime(); root.tag = tag
            val key = getSharedPreferences("lws", MODE_PRIVATE).getString("api_key", "") ?: ""
            val noKeyMsg = "বিস্তারিত ব্যাখ্যা পেতে অ্যাপের হোম স্ক্রিনে Claude API key দিন।"
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                .hideSoftInputFromWindow(input.windowToken, 0)

            Thread {
                // ১) হাতে লেখা অভিধান (অর্থ + ব্যাখ্যা)
                val local = Dictionary.local(this, word)
                if (local != null) {
                    ui.post {
                        if (root.tag != tag) return@post
                        orthoTv.text = local.ortho; bekkhaTv.text = local.bekkha
                        status.text = "অফলাইন অভিধান"
                    }
                    return@Thread
                }
                // ২) বড় অফলাইন অভিধান (শুধু অর্থ)
                val bigMeaning = Dictionary.bigLookup(this, word)
                if (bigMeaning != null) {
                    ui.post {
                        if (root.tag != tag) return@post
                        orthoTv.text = bigMeaning
                        status.text = "অফলাইন অভিধান"
                        bekkhaTv.text = if (key.isNotBlank()) "AI ব্যাখ্যা আনছে…" else noKeyMsg
                    }
                } else {
                    // ৩) ML Kit অনুবাদ
                    ui.post {
                        Dictionary.mlKit(word) { t ->
                            if (root.tag != tag) return@mlKit
                            if (t != null && orthoTv.text.isEmpty()) {
                                orthoTv.text = t
                                status.text = "অফলাইন অনুবাদ"
                            } else if (t == null && orthoTv.text.isEmpty()) {
                                status.text = "অর্থ পাওয়া যায়নি (প্রথমবার ইন্টারনেট লাগবে, ভাষার ফাইল ডাউনলোডের জন্য)"
                            }
                        }
                        bekkhaTv.text = if (key.isNotBlank()) "AI ব্যাখ্যা আনছে…" else noKeyMsg
                    }
                }
                // ৪) AI দিয়ে বিস্তারিত ব্যাখ্যা
                if (key.isNotBlank()) {
                    val e = Dictionary.ai(key, word)
                    ui.post {
                        if (root.tag != tag) return@post
                        if (e != null) {
                            orthoTv.text = e.ortho; bekkhaTv.text = e.bekkha; status.text = "AI দিয়ে তৈরি"
                        } else if (bekkhaTv.text.toString().startsWith("AI")) {
                            bekkhaTv.text = "ব্যাখ্যা আনা যায়নি (ইন্টারনেট/API key পরীক্ষা করুন)।"
                        }
                    }
                }
            }.start()
        }
        btn.setOnClickListener { search() }
        input.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEARCH) { search(); true } else false
        }

        val lp = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.92).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(60)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        }
        wm.addView(root, lp)
        panel = root

        input.requestFocus()
        input.postDelayed({
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                .showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
        }, 200)
    }
}
