package com.lws.translation

import android.content.Context
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Entry(val ortho: String, val bekkha: String)

object Dictionary {

    fun isBangla(s: String) = s.any { it in '\u0980'..'\u09FF' }

    /** Offline: assets/dictionary.json theke khuje ber kore */
    fun local(ctx: Context, word: String): Entry? = try {
        val json = ctx.assets.open("dictionary.json").bufferedReader().use { it.readText() }
        val obj = JSONObject(json)
        val key = word.trim().lowercase()
        if (obj.has(key)) {
            val e = obj.getJSONObject(key)
            Entry(e.getString("ortho"), e.getString("bekkha"))
        } else null
    } catch (e: Exception) { null }

    private var big: HashMap<String, String>? = null

    /** Offline: বড় অভিধান (assets/words.tsv), প্রথমবার মেমরিতে লোড হয় */
    @Synchronized
    fun bigLookup(ctx: Context, word: String): String? {
        if (big == null) {
            val m = HashMap<String, String>(250000)
            try {
                ctx.assets.open("words.tsv").bufferedReader(Charsets.UTF_8).useLines { lines ->
                    for (l in lines) {
                        val i = l.indexOf('\t')
                        if (i > 0) m[l.substring(0, i)] = l.substring(i + 1)
                    }
                }
            } catch (e: Exception) { }
            big = m
        }
        return big!![word.trim().lowercase()]
    }

    /** Offline: Google ML Kit (prothombar model download hobe, tarpor offline kaj korbe) */
    fun mlKit(word: String, cb: (String?) -> Unit) {
        val toEnglish = isBangla(word)
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(if (toEnglish) TranslateLanguage.BENGALI else TranslateLanguage.ENGLISH)
            .setTargetLanguage(if (toEnglish) TranslateLanguage.ENGLISH else TranslateLanguage.BENGALI)
            .build()
        val tr = Translation.getClient(options)
        tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                tr.translate(word)
                    .addOnSuccessListener { cb(it) }
                    .addOnFailureListener { cb(null) }
            }
            .addOnFailureListener { cb(null) }
    }

    /** Online: Claude API diye bistarito ortho + bekkha. Background thread e call korte hobe. */
    fun ai(apiKey: String, word: String): Entry? {
        return try {
            val toEnglish = isBangla(word)
            val prompt = """
                You are a Bangla-English dictionary. Word: "$word".
                Give meanings in ${if (toEnglish) "English" else "Bangla (Bengali script)"} with part of speech.
                Then give a detailed explanation ("bekkha") written in Bangla (Bengali script): what it means,
                in which contexts it is used, and 2 example sentences with translation.
                Reply ONLY with JSON, no markdown: {"ortho":"...","bekkha":"..."}
            """.trimIndent()

            val body = JSONObject().apply {
                put("model", "claude-haiku-4-5-20251001")
                put("max_tokens", 900)
                put("messages", JSONArray().put(
                    JSONObject().put("role", "user").put("content", prompt)))
            }

            val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 10000
            conn.readTimeout = 25000
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            conn.setRequestProperty("x-api-key", apiKey)
            conn.setRequestProperty("anthropic-version", "2023-06-01")
            conn.outputStream.use { it.write(body.toString().toByteArray()) }

            if (conn.responseCode != 200) return null
            val resp = conn.inputStream.bufferedReader().use { it.readText() }
            var text = JSONObject(resp).getJSONArray("content").getJSONObject(0).getString("text")
            text = text.replace("```json", "").replace("```", "").trim()
            val r = JSONObject(text)
            Entry(r.getString("ortho"), r.getString("bekkha"))
        } catch (e: Exception) { null }
    }
}
