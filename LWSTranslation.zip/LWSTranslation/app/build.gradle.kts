import java.net.URL

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.lws.translation"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.lws.translation"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("com.google.mlkit:translate:17.0.3")
}

// ---- বিল্ডের সময় বড় অভিধান নামিয়ে words.tsv বানায় (ব্যর্থ হলেও বিল্ড চলবে) ----
val dictOut: File = file("src/main/assets/words.tsv")

fun splitCsvLine(line: String, sep: Char): List<String> {
    val parts = ArrayList<String>()
    val sb = StringBuilder()
    var inQuote = false
    for (c in line) {
        if (c == '"') {
            inQuote = !inQuote
        } else if (c == sep && !inQuote) {
            parts.add(sb.toString())
            sb.setLength(0)
        } else {
            sb.append(c)
        }
    }
    parts.add(sb.toString())
    return parts
}

fun isBengaliText(t: String): Boolean {
    for (ch in t) {
        if (ch >= '\u0980' && ch <= '\u09FF') return true
    }
    return false
}

fun isEnglishWord(t: String): Boolean {
    if (t.isEmpty()) return false
    val first = t[0]
    val firstOk = (first in 'a'..'z') || (first in 'A'..'Z')
    if (!firstOk) return false
    for (ch in t) {
        val ok = (ch in 'a'..'z') || (ch in 'A'..'Z') || ch == ' ' || ch == '-' || ch == '\'' || ch == '.'
        if (!ok) return false
    }
    return true
}

fun addPair(map: HashMap<String, LinkedHashSet<String>>, key: String, value: String) {
    var set = map[key]
    if (set == null) {
        set = LinkedHashSet<String>()
        map[key] = set
    }
    set.add(value)
}

val fetchDict = tasks.register("fetchDict") {
    doLast {
        try {
            val link = "https://github.com/MinhasKamal/BengaliDictionary/raw/refs/heads/master/BengaliDictionary_93.csv"
            val stream = URL(link).openStream()
            val bytes: ByteArray = stream.readBytes()
            stream.close()
            val text = String(bytes, Charsets.UTF_8)

            val en2bn = HashMap<String, LinkedHashSet<String>>()
            val bn2en = HashMap<String, LinkedHashSet<String>>()

            val lines: List<String> = text.split("\n")
            for (line in lines) {
                if (line.isBlank()) continue
                val sep: Char = if (line.indexOf('\t') >= 0) '\t' else ','
                val cells = splitCsvLine(line, sep)
                var en = ""
                val bnList = ArrayList<String>()
                for (raw in cells) {
                    val cell = raw.trim()
                    if (en.isEmpty() && isEnglishWord(cell)) {
                        en = cell.lowercase()
                    } else if (isBengaliText(cell)) {
                        bnList.add(cell)
                    }
                }
                if (en.isEmpty() || bnList.isEmpty()) continue
                for (b in bnList) {
                    addPair(en2bn, en, b)
                    addPair(bn2en, b, en)
                }
            }

            val out = StringBuilder()
            for (entry in en2bn.entries) {
                out.append(entry.key).append('\t').append(entry.value.toList().take(8).joinToString(", ")).append('\n')
            }
            for (entry in bn2en.entries) {
                out.append(entry.key).append('\t').append(entry.value.toList().take(8).joinToString(", ")).append('\n')
            }
            dictOut.parentFile.mkdirs()
            dictOut.writeText(out.toString())
            println("Dictionary words: " + (en2bn.size + bn2en.size))
        } catch (e: Exception) {
            println("Dictionary download failed: " + e)
            dictOut.parentFile.mkdirs()
            if (!dictOut.exists()) dictOut.writeText("")
        }
    }
}

tasks.named("preBuild") { dependsOn(fetchDict) }
