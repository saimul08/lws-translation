plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.lws.translation"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.lws.translation"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("com.google.mlkit:translate:17.0.3")
}

// ---- বিল্ডের সময় বড় অভিধান নামিয়ে words.tsv বানায় (ব্যর্থ হলেও বিল্ড চলবে) ----
val dictOut = layout.projectDirectory.file("src/main/assets/words.tsv").asFile

val fetchDict = tasks.register("fetchDict") {
    doLast {
        try {
            val url = "https://github.com/MinhasKamal/BengaliDictionary/raw/refs/heads/master/BengaliDictionary_93.csv"
            val bytes = java.net.URL(url).openStream().use { it.readBytes() }
            val text = String(bytes, Charsets.UTF_8)
            val enRe = Regex("^[A-Za-z][A-Za-z '.\\-]*$")
            val en2bn = LinkedHashMap<String, LinkedHashSet<String>>()
            val bn2en = LinkedHashMap<String, LinkedHashSet<String>>()

            fun splitLine(line: String, sep: Char): List<String> {
                val out = ArrayList<String>()
                val sb = StringBuilder()
                var inQuote = false
                for (c in line) {
                    if (c == '"') {
                        inQuote = !inQuote
                    } else if (c == sep && !inQuote) {
                        out.add(sb.toString())
                        sb.setLength(0)
                    } else {
                        sb.append(c)
                    }
                }
                out.add(sb.toString())
                return out
            }

            for (line in text.lineSequence()) {
                if (line.isBlank()) continue
                val sep = if (line.contains('\t')) '\t' else ','
                val cells = splitLine(line, sep).map { it.trim() }
                val en = cells.firstOrNull { enRe.matches(it) }?.lowercase() ?: continue
                val bn = cells.filter { c -> c.any { ch -> ch in '\u0980'..'\u09FF' } }
                if (bn.isEmpty()) continue
                for (b in bn) {
                    en2bn.getOrPut(en) { LinkedHashSet() }.add(b)
                    bn2en.getOrPut(b) { LinkedHashSet() }.add(en)
                }
            }

            val sb = StringBuilder()
            for ((k, v) in en2bn) sb.append(k).append('\t').append(v.take(8).joinToString(", ")).append('\n')
            for ((k, v) in bn2en) sb.append(k).append('\t').append(v.take(8).joinToString(", ")).append('\n')
            dictOut.parentFile.mkdirs()
            dictOut.writeText(sb.toString())
            println("Dictionary words: " + (en2bn.size + bn2en.size))
        } catch (e: Exception) {
            println("Dictionary download failed: " + e)
            dictOut.parentFile.mkdirs()
            if (!dictOut.exists()) dictOut.writeText("")
        }
    }
}

tasks.named("preBuild") { dependsOn(fetchDict) }
